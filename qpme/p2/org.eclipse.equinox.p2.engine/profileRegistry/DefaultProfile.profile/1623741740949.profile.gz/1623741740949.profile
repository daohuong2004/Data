<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1623741740949'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/home/runner/work/QPME/QPME/sources/qpme.releng.product/target/products/qpme.product/win32/win32/x86_64/qpme'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/runner/work/QPME/QPME/sources/qpme.releng.product/target/products/qpme.product/win32/win32/x86_64/qpme'/>
  </properties>
</profile>
